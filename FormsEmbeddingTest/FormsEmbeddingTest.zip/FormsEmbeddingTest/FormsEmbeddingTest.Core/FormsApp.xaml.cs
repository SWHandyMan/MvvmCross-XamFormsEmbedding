﻿using MvvmCross.Core.ViewModels;
using MvvmCross.Forms.Platform;
using MvvmCross.Platform;
using Xamarin.Forms;

namespace FormsEmbeddingTest.Core
{
    public partial class FormsApp : MvxFormsApplication
    {
        public FormsApp()
        {
            InitializeComponent();
        }
    }
}
